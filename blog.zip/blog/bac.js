const express=require('express');
const app=express();
const bodyParser=require('body-parser');
const db=require('./model/db.js');
const ejs=require('ejs');
app.set('view engine','ejs');
// 配置socket.io
const http=require('http').Server(app);
const io=require('socket.io')(http)
const cookieParser=require('cookie-parser');
// 配置可以使用cookie
app.use(cookieParser());
// 呈递静态资源
app.use('/public',express.static('./public/'));
var urlencodedParser = bodyParser.urlencoded({ extended: false });
let fx=db.insert;
let fx1=db.find;
let fx2=db.drop
app.get('/insert',(req,res)=>{
	fx({user:req.query.user,tips:req.query.tips,msg:req.query.msg},'local','blogInfo',function(result){
						if(result.length!=0){
							res.send("插入成功")
						}else{
							res.status(500).send('插入失败')
						}
			})
	
})
app.get('/find',(req,res)=>{
	let skip=parseInt(req.query.skip);
	let obj=req.query.obj;
	fx1(obj,'local','blogInfo',skip,10,function(result){
						if(result.length!=0){
							res.send(result)
						}else{
							 res.status(404).send('查询失败')
						}
			})
	
})
app.post('/login',urlencodedParser,(req,res)=>{
	fx1({user:req.body.user,psw:req.body.psw},'local','userInfo',0,0,function(result){
						if(result.length!=0){
							res.cookie('user',req.body.user,{maxAge:1000000,httponly:true});
							res.render('blog',{user:req.body.user})
						}else{
							 res.status(404).send('用户名或密码错误')
						}
			})
	
})
app.post('/register', urlencodedParser, (req,res)=>{
			fx1({user:req.body.user},'local','userInfo',0,0,function(result){
				if(result.length!=0){
					res.send('用户名已被注册了！')
				}else{
					fx({user:req.body.user,psw:req.body.psw},'local','userInfo',function(result){
						if(result.insertedCount!=0){
							res.send("注册成功");
						}else{
							res.status(404).send("注册失败");
						}
					});
				}
			})
			
		})
app.get('/drop',(req,res)=>{
	fx2({user:req.query.name},'local','userInfo',function(result){
				if(result.deletedCount!=0){
					res.send("注销成功");
				}else{
					res.status(404).send("已被注销");
				}
	});
})
app.get('/chat', urlencodedParser, (req,res)=>{
	res.render('chat',{user:req.cookies.user})
})
app.use('/',(req,res)=>{
	if(req.cookies.user){
		res.render('blog',{user:req.cookies.user})
	}else{
		res.render('login')
	}
})
io.on('connection',(socket)=>{
	// 服务器收到客户端请求
	socket.on('chat',(msg)=>{
	//服务端发送数据
			io.emit('send',msg)
		})
	})
http.listen('8989')
