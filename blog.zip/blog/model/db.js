const mongoClient=require('mongodb').MongoClient;
let url="mongodb://localhost:27017"
var _connect=function(callback){
	mongoClient.connect(url,{ useUnifiedTopology: true },(err,db)=>{
		if (err) throw err;
        callback(db);   
	})
}
module.exports.insert=function(obj,dbName,collectionName,callback){
        _connect(function(db){
			if(!Array.isArray(obj)){
				obj=[obj];
			}
            db.db(dbName).collection(collectionName).insertMany(obj,(err,result)=>{
                if (err) throw err;
                db.close();
				callback(result);
            })
        }   
    )
}
module.exports.find=function(obj={},dbName,collectionName,skip=0,limit=10,callback){
    _connect(function(db){
        db.db(dbName).collection(collectionName).find(obj).limit(limit).skip(skip).sort({tips:-1}).toArray((err,result)=>{
            if (err) throw err;
            db.close();
            callback(result);
        })
    }   
)
}
module.exports.drop=function(obj,dbName,collectionName,callback){
    _connect(function(db){
        db.db(dbName).collection(collectionName).deleteOne(obj,(err,result)=>{
            if (err) throw err;
            db.close();
            callback(result);
        })
    }   
)
}